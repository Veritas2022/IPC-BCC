/* Ajoute les permissions de géolocalisation au manifeste Android généré par Capacitor.
   Exécuté automatiquement par la chaîne de compilation, après « npx cap add android ». */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';

const chemin = 'android/app/src/main/AndroidManifest.xml';
if (!existsSync(chemin)) {
  console.error('Manifeste introuvable — lancez d’abord « npx cap add android ».');
  process.exit(1);
}
let x = readFileSync(chemin, 'utf8');
const permissions = [
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.INTERNET'
];
let ajoutees = 0;
for (const p of permissions) {
  if (!x.includes(p)) {
    x = x.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`);
    ajoutees++;
  }
}
writeFileSync(chemin, x);
console.log(`Manifeste : ${ajoutees} permission(s) ajoutée(s).`);
